#!/bin/sh
# query directory for smail
# M. Andreoli for mulinux

wave -c 440 1

echo "$@" > /tmp/query

domain=`domainname`
host=`hostname`

case "$1" in

\[*)	# look for internet addresses in square brackets
	inet=`echo "$1" | sed -n 's/^\[\([0-9.]*\)\]$/[\1]/p'`
	if [ "$inet" ]; then
		echo $inet smtp
	else
		exit 1
	fi;;
me|localhost|$host|$host.$domain)	
	echo localhost local
	;;
*.$domain)
	echo $1 smtp 
	;;
x)
	echo "scaz.com smtp"
	;;
*)	echo 
	;;

esac

exit 0
