#!/bin/ash
# Sun Feb 20 07:50 2000 - A. Costa
# Time how long a command takes in seconds.
#Syntax

opt=$1

case Z$opt in
Z-d) set -x;shift;;     # debug mode...
Z-h|Z) echo "Usage : timeit [-h] command [args...]" ; exit ;;
*)
esac

# get start time.
# NOTE: `cat /proc/uptime` outputs two numbers like "123.45 125.67",
# so the sed stuff gets rid of all but the "123"
begintime=`cat /proc/uptime | sed 's/\..*$//'`
eval "$@"
endtime=`cat /proc/uptime | sed 's/\..*$//'`
expr $endtime - $begintime
